DROP TABLE user_ARS;
DROP TABLE location;
DROP TABLE airports;
DROP TABLE flightInfo;
DROP TABLE bookingInfo;

CREATE TABLE userARS(
uName VARCHAR2(20) ,
userName VARCHAR2(20) UNIQUE,
uMail VARCHAR2(50) PRIMARY KEY,
pwd VARCHAR2(50),
role VARCHAR2(50),
mblNo VARCHAR2(10) UNIQUE,
securityQuestion VARCHAR2(50),
securityAnswer VARCHAR2(50));

CREATE TABLE flightInfo(flightNo NUMBER(5),
airline VARCHAR2(10),
dep_city VARCHAR2(10),
arr_city VARCHAR2(10),
dep_date DATE,
arr_date DATE,
dep_time VARCHAR2(6),
arr_time VARCHAR2(6),
FirstSeats NUMBER(2),
FirstSeatFare NUMBER(10,2),
bussSeats NUMBER(2),
bussSeatsFare NUMBER(10,2),
FlightDate VARCHAR2(50)primary key);

CREATE TABLE bookingInfo(Booking_id VARCHAR2(50) primary key,
umail VARCHAR2(100) REFERENCES userARS(umail),
no_of_passengers NUMBER,
class_type VARCHAR2(50),
total_fare NUMBER(10,2),
CreditCard_info VARCHAR2(50),
src_city VARCHAR2(20),
dest_city VARCHAR2(20),
deptDate DATE,
flightNo NUMBER,
FlightDate VARCHAR2(100) references FlightInfo(FlightDate));

insert into bookingInfo values('Vistara1005','shikha@capgemini.com',1,'FirstClass',2300,'123asqaz','pune','himachal','23-JAN-2017',1006,'10062312017');


CREATE TABLE location(CITY VARCHAR2(20),
abbr VARCHAR2(5) UNIQUE,
STATE VARCHAR(20),
zipcode NUMBER(6) PRIMARY KEY);

CREATE TABLE airports(aptId NUMBER PRIMARY KEY,
aptName VARCHAR2(20),
abbr VARCHAR2(5) UNIQUE,
zipcode NUMBER(6) REFERENCES location(zipcode));


insert into userARS values('poga','poga','shiksadha@capgemini.com','123456','EXECUTIVE','9631145671', '1' ,'xyz');

insert into flightinfo values(1001,'Indigo','pune','himachal','23-JAN-2017','24-JAN-2017','10:56','11:58',20,2300,40,1000,'10012112017');
insert into flightinfo values(1002,'SpiceJet','Kolkata','Pune','24-JAN-2017','25-JAN-2017','08:24','10:15',20,3300,40,1000,'10022412017');
insert into flightinfo values(1003,'SpiceJet','Pune','Kolkata','23-JAN-2017','24-JAN-2017','09:24','10:15',20,3300,40,1000,'10032312017');
insert into flightinfo values(1004,'AirIndia','bangalore','Mumbai','23-JAN-2017','24-JAN-2017','10:56','01:78',20,2300,40,1000,'10042312017');
insert into flightinfo values(1005,'JetAirways','pune','himachal','24-JAN-2017','25-JAN-2017','08:56','11:78',20,2300,40,1000,'10052412017');
insert into flightinfo values(1006,'Vistara','pune','himachal','23-JAN-2017','25-JAN-2017','10:56','11:56',20,2300,40,1000,'10062312017');
insert into flightinfo values(1007,'Qatar','Ranchi','pune','23-JAN-2017','24-JAN-2017','10:56','01:78',20,2300,40,1000,'10072312017');
insert into flightinfo values(1008,'Airbus69','kolkata','ranchi','24-JAN-2017','25-JAN-2017','9:56','11:38',20,2300,40,1000,'10082412017');
insert into flightinfo values(1009,'Indigo','pune','himachal','23-JAN-2017','25-JAN-2017','08:56','11:28',20,2300,40,1000,'10092312017');
insert into flightinfo values(1010,'SpiceJet','kolkata','himachal','24-JAN-2017','25-JAN-2017','09:56','11:28',20,2300,40,1000,'10102412017');
insert into flightinfo values(1011,'AirIndia','pune','himachal','23-JAN-2017','24-JAN-2017','10:56','11:08',20,2300,40,1000,'10112312017');
insert into flightinfo values(1012,'Qatar','pune','himachal','23-JAN-2017','24-JAN-2017','10:56','11:28',20,2300,40,1000,'10132312017');
insert into flightinfo values(1013,'Airbus69','chandigarh','delhi','24-JAN-2017','25-JAN-2017','10:56','11:18',20,2300,40,1000,'10132412017');
insert into flightinfo values(1014,'JetAirways','pune','himachal','23-JAN-2017','25-JAN-2017','10:56','11:58',20,2300,40,1000,'10142312017');
insert into flightinfo values(1015,'Vistara','pune','himachal','23-JAN-2017','24-JAN-2017','08:56','10:28',20,2300,40,1000,'10152312017');
insert into flightinfo values(1016,'Indigo','mumbai','amritsar','24-JAN-2017','25-JAN-2017','10:56','11:58',20,2300,40,1000,'10162412017');
insert into flightinfo values(1017,'JetAirways','delhi','ranchi','23-JAN-2017','25-JAN-2017','09:56','11:18',20,2300,40,1000,'10172312017');
insert into flightinfo values(1018,'Vistara','hyderabad','amritsar','23-JAN-2017','24-JAN-2017','08:56','10:18',20,2300,40,1000,'10182312017');
insert into flightinfo values(1019,'Vistara','himachal','pune','25-JAN-2017','26-JAN-2017','08:56','10:18',20,2300,40,1000,'10192512017');
insert into flightinfo values(1060,'Vistara','delhi','pune','4-FEB-2017','5-FEB-2017','09:00','10:59',20,2300,40,1000,'10600422017');
insert into flightinfo values(1061,'Vistara','delhi','pune','4-FEB-2017','5-FEB-2017','12:15','14:45',20,2300,40,1000,'10610422017');
insert into flightinfo values(1062,'Vistara','delhi','pune','4-FEB-2017','5-FEB-2017','14:20','16:50',20,2300,40,1000,'10620422017');
insert into flightinfo values(1063,'Vistara','delhi','pune','4-FEB-2017','5-FEB-2017','18:00','20:20',20,2300,40,1000,'10630422017');
insert into flightinfo values(1064,'Vistara','delhi','pune','5-FEB-2017','6-FEB-2017','20:15','22:45',20,2300,40,1000,'10640522017');
insert into flightinfo values(1065,'JetAirways','kolkata','mumbai','6-FEB-2017','7-FEB-2017','09:00','10:59',20,2300,40,1000,'10650622017');
insert into flightinfo values(1066,'JetAirways','kolkata','mumbai','6-FEB-2017','7-FEB-2017','12:15','14:45',20,2300,40,1000,'10660622017');
insert into flightinfo values(1067,'JetAirways','kolkata','mumbai','6-FEB-2017','7-FEB-2017','14:20','16:50',20,2300,40,1000,'10670622017');
insert into flightinfo values(1068,'JetAirways','kolkata','mumbai','6-FEB-2017','7-FEB-2017','18:00','20:20',20,2300,40,1000,'10680622017');
insert into flightinfo values(1069,'JetAirways','kolkata','mumbai','6-FEB-2017','7-FEB-2017','20:15','22:45',20,2300,40,1000,'10690622017');
insert into flightinfo values(1070,'JetAirways','kolkata','mumbai','7-FEB-2017','8-FEB-2017','17:00','21:20',20,2300,40,1000,'10700722017');
insert into flightinfo values(1071,'Indigo','himachal','kolkata','4-FEB-2017','6-FEB-2017','09:00','10:59',20,2300,40,1000,'10710422017');
insert into flightinfo values(1072,'Indigo','himachal','kolkata','4-FEB-2017','6-FEB-2017','12:15','14:45',20,2300,40,1000,'10720422017');
insert into flightinfo values(1073,'Indigo','himachal','kolkata','4-FEB-2017','6-FEB-2017','14:20','16:50',20,2300,40,1000,'10730422017');
insert into flightinfo values(1074,'Indigo','himachal','kolkata','4-FEB-2017','6-FEB-2017','18:00','20:20',20,2300,40,1000,'10740422017');
insert into flightinfo values(1075,'Indigo','himachal','kolkata','7-FEB-2017','8-FEB-2017','20:15','22:45',20,2300,40,1000,'10750722017');
insert into flightinfo values(1076,'SpiceJet','bangalore','kolkata','5-FEB-2017','6-FEB-2017','09:00','10:59',20,2300,40,1000,'10760522017');
insert into flightinfo values(1077,'SpiceJet','bangalore','kolkata','5-FEB-2017','6-FEB-2017','12:15','14:45',20,2300,40,1000,'10770522017');
insert into flightinfo values(1078,'SpiceJet','bangalore','kolkata','5-FEB-2017','6-FEB-2017','14:20','16:50',20,2300,40,1000,'10780522017');
insert into flightinfo values(1079,'SpiceJet','bangalore','kolkata','6-FEB-2017','7-FEB-2017','20:15','22:45',20,2300,40,1000,'10790622017');

insert into flightinfo values(1080,'Vistara','pune','delhi','4-FEB-2017','5-FEB-2017','09:00','10:59',20,2300,40,1000,'10800422017');
insert into flightinfo values(1081,'Vistara','pune','delhi','4-FEB-2017','5-FEB-2017','08:00','10:59',20,2300,40,1000,'10810422017');
insert into flightinfo values(1082,'Vistara','pune','delhi','5-FEB-2017','6-FEB-2017','10:00','12:59',20,2300,40,1000,'10820522017');
insert into flightinfo values(1083,'JetAirways','mumbai','kolkata','6-FEB-2017','7-FEB-2017','09:00','10:59',20,2300,40,1000,'10830622017');
insert into flightinfo values(1084,'JetAirways','mumbai','kolkata','6-FEB-2017','7-FEB-2017','12:15','14:45',20,2300,40,1000,'10840622017');
insert into flightinfo values(1085,'JetAirways','mumbai','kolkata','7-FEB-2017','8-FEB-2017','14:20','16:50',20,2300,40,1000,'10850722017');

insert into flightinfo values(1086,'Indigo','kolkata','himachal','4-FEB-2017','6-FEB-2017','09:00','10:59',20,2300,40,1000,'10860422017');
insert into flightinfo values(1087,'Indigo','kolkata','himachal','7-FEB-2017','8-FEB-2017','12:15','14:45',20,2300,40,1000,'10870722017');
insert into flightinfo values(1088,'Indigo','kolkata','himachal','4-FEB-2017','6-FEB-2017','14:20','16:50',20,2300,40,1000,'1088042017');

insert into flightinfo values(1089,'SpiceJet','kolkata','bangalore','5-FEB-2017','6-FEB-2017','09:00','10:59',20,2300,40,1000,'10890522017');
insert into flightinfo values(1090,'SpiceJet','kolkata','bangalore','5-FEB-2017','6-FEB-2017','12:15','14:45',20,2300,40,1000,'10900522017');
insert into flightinfo values(1091,'SpiceJet','kolkata','bangalore','6-FEB-2017','7-FEB-2017','14:20','16:50',20,2300,40,1000,'10910622017');

delete from flightinfo where flightDate='10192512017';

select * from user_ars;

select * from flightInfo where flightdate = 10112312017