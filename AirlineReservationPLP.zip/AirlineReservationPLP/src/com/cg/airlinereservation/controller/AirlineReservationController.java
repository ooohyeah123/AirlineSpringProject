/**
 ***********************************************************************************
 * File:        AirlineReservationController.java
 * Package:     com.cg.airlinereservation.controller
 * Desc:        Server Unit to handle all request from users
 * Version:     1.0
 * Modifications:
 * Author:            Date:          	Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
 */

package com.cg.airlinereservation.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;
import com.cg.airlinereservation.logFile.LogInfo;
import com.cg.airlinereservation.service.IAdminService;
import com.cg.airlinereservation.service.ICustomerService;
import com.cg.airlinereservation.service.IUserService;
import com.cg.airlinereservation.utility.AirlineReservationConstants;

@Controller
@SessionAttributes({"user","noOfPassengers","classType","userName"})
public class AirlineReservationController 
{	
	private static Logger myLogger;

	public AirlineReservationController() {
		myLogger =  Logger.getLogger(LogInfo.class);
	}

	@Autowired
	private IUserService userService;

	@Autowired
	private ICustomerService customerService;

	@Autowired
	private IAdminService adminService;

	private int noOfPassengers;
	private String classType;

	/**
	 * Redirection to the home page using web.xml configuration
	 * @param model
	 * @param session
	 * @return String
	 */
	@RequestMapping(value=AirlineReservationConstants.INDEX_MAPPING,method=RequestMethod.GET)
	public String showHome(Model model, HttpSession session)
	{
		model.addAttribute("depCity",new String[]{"Amritsar","Bangalore","Pune","Kolkata","Mumbai","Himachal","Ranchi","Delhi","Hyderabad"});
		model.addAttribute("arrCity",new String[]{"Amritsar","Bangalore","Pune","Kolkata","Mumbai","Himachal","Ranchi","Delhi","Hyderabad"});
		model.addAttribute(AirlineReservationConstants.FLIGHTINFO, new FlightInfo());
		return AirlineReservationConstants.INDEX_PAGE;	
	}

	/**
	 * Redirection to the login page
	 * @param model 
	 * @return String	
	 */
	@RequestMapping(value=AirlineReservationConstants.LOGIN_FORM,method=RequestMethod.GET)
	public String loginForm(Model model){
		model.addAttribute(AirlineReservationConstants.USER, new UserARS());
		return AirlineReservationConstants.LOGIN;	
	}

	/**
	 * Enabling a user to login and fetching the username to be set in the session
	 * @param user
	 * @param res
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.LOGIN,method=RequestMethod.POST)
	public String login(@ModelAttribute(AirlineReservationConstants.USER)@Valid UserARS user, BindingResult res, Model model) throws ServletException
	{
		String view = "";
		try {
			UserARS userARS = userService.getUser(user);
			model.addAttribute(AirlineReservationConstants.USERNAME,userARS.getUserName());
			model.addAttribute(AirlineReservationConstants.USER, userARS);
			model.addAttribute(AirlineReservationConstants.FLIGHTINFO, new FlightInfo());
			model.addAttribute("depCity",new String[]{"Amritsar","Bangalore","Pune","Kolkata","Mumbai","Himachal","Ranchi","Delhi","Hyderabad"});
			model.addAttribute("arrCity",new String[]{"Amritsar","Bangalore","Pune","Kolkata","Mumbai","Himachal","Ranchi","Delhi","Hyderabad"});
			view =AirlineReservationConstants.INDEX_PAGE;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;	
	}

	/**
	 * Redirection to the registration page for a new user
	 * @param model
	 * @return String
	 */
	@RequestMapping(value=AirlineReservationConstants.REGISTERFORM,method=RequestMethod.GET)
	public String registerForm(Model model)
	{
		model.addAttribute(AirlineReservationConstants.USER, new UserARS());
		model.addAttribute(AirlineReservationConstants.SECURITYQUESTION,new String[]{"Mother's Maiden Name","Pet Dog's Name","Who gave You your First Failing Grade?","City/Town your Nearest sibling live?"});
		return AirlineReservationConstants.REGISTER;	
	}

	/**
	 * Validation of the registration data and redirection to the login page
	 * @param user
	 * @param res
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.REGISTER,method=RequestMethod.POST)
	public String register(@ModelAttribute(AirlineReservationConstants.USER)@Valid UserARS user, BindingResult res, Model model) throws ServletException
	{
		String view = "";

		if(res.hasErrors())
		{
			model.addAttribute(AirlineReservationConstants.SECURITYQUESTION,new String[]{"Mother's Maiden Name","Pet Dog's Name","Who gave You your First Failing Grade?","City/Town your Nearest sibling live?"});
			model.addAttribute(AirlineReservationConstants.USER, user);
			model.addAttribute("msg","Oops!Registered failed!");
			view = AirlineReservationConstants.REGISTER;
		} else
		{
			try {
				user.setRole(AirlineReservationConstants.CUSTOMER);
				userService.addUser(user);
				model.addAttribute("msg","Registered successfully!");
				view=AirlineReservationConstants.LOGIN;

			} catch (ARSException e) {
				myLogger.error(e.getMessage());
				throw new ServletException(e.getMessage(),e);
			}
		}
		return view;	
	}
	/**
	 * Display the flights for a specific search and updation of seats
	 * @param flightInfo
	 * @param noOfPassengers
	 * @param classType
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.GETALLFLIGHTS,method=RequestMethod.POST)
	public String getAllFlights(@ModelAttribute(AirlineReservationConstants.FLIGHTINFO) FlightInfo flightInfo,@RequestParam("noOfPassengers") int noOfPassengers,@RequestParam("classType") String classType, Model model) throws ServletException
	{
		String view = "";
		try {
			int firstSeats = 0;
			int bussSeats = 0;
			if (classType.equalsIgnoreCase(AirlineReservationConstants.FIRSTCLASS)) {
				firstSeats = noOfPassengers;
			} else {
				bussSeats = noOfPassengers;
			}
			this.noOfPassengers=noOfPassengers;
			this.classType=classType;
			flightInfo.setFirstSeats(firstSeats);
			flightInfo.setBussSeats(bussSeats);
			List<FlightInfo> flightList = customerService.getAllFlights(flightInfo);
			model.addAttribute(AirlineReservationConstants.FLIGHTLIST,flightList);
			view = AirlineReservationConstants.FLIGHTS;

		} catch (Exception e) {
			throw new ServletException(e.getMessage(),e);
		}

		return view;	
	}
	/**
	 * Redirection to the booking form page
	 * @param flightDate
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.ADDBOOKINGFORM,method=RequestMethod.GET)
	public String addBookingForm(@RequestParam("flightDate") String flightDate, Model model) throws ServletException
	{
		String view = "";
		try {
			FlightInfo flightInfo = adminService.getFlightInfoReturn(flightDate);
			double totalFare = 0;
			if(this.classType.equals(AirlineReservationConstants.FIRSTCLASS)){
				totalFare = this.noOfPassengers * flightInfo.getFirstSeatfare();
			}else{
				totalFare = this.noOfPassengers * flightInfo.getBussSeatsFare();
			}
			List<UserARS> userList = customerService.getAllCustomers();
			List<String> uMail = new ArrayList<String>();
			for (UserARS val : userList) {
				uMail.add(val.getuMail());
			}
			model.addAttribute(AirlineReservationConstants.UMAIL,uMail);
			model.addAttribute(AirlineReservationConstants.NOOFPASSENGERS, this.noOfPassengers);
			model.addAttribute(AirlineReservationConstants.CLASSTYPE,this.classType);
			model.addAttribute(AirlineReservationConstants.FLIGHTINFO,flightInfo);
			model.addAttribute(AirlineReservationConstants.TOTALFARE,totalFare);
			model.addAttribute(AirlineReservationConstants.BOOKINGINFO, new BookingInfo());
			view=AirlineReservationConstants.BOOKINGFLIGHT;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}

		return view;	
	}

	/**
	 * Creating a booking and updating the no.of seats left
	 * @param bookingInfo
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.ADDBOOKING,method=RequestMethod.POST)
	public String addBooking(@ModelAttribute(AirlineReservationConstants.BOOKINGINFO) BookingInfo bookingInfo, Model model) throws ServletException
	{
		String view = "";
		try {
			FlightInfo flightInfo = adminService.getFlightInfoReturn(bookingInfo.getFlightInfo().getFlightDate());
			int id = customerService.bookingId();
			String bookingId = flightInfo.getAirLine() + id;
			bookingInfo.setBooking_Id(bookingId);
			if (bookingInfo.getClass_Type().equals("FirstClass"))
			{
				int remaining = (int) (flightInfo.getFirstSeats() - bookingInfo.getNo_of_passengers());
				flightInfo.setFirstSeats(remaining);
			}
			else
			{
				int remaining = (int) (flightInfo.getBussSeats() - bookingInfo.getNo_of_passengers());
				flightInfo.setBussSeats(remaining);
			}

			customerService.addBookingInfo(bookingInfo);
			adminService.updateFlightInfo(flightInfo);
			model.addAttribute(AirlineReservationConstants.BOOKINGINFO,bookingInfo);
			view=AirlineReservationConstants.BOOKINGSUCCESS;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}		
		return view;	
	}

	/**
	 * Method for round booking of flights and updating of the no.of seats thereafter
	 * @param flightInfo
	 * @param noOfPassengers
	 * @param returnDate
	 * @param classType
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.ROUNDBOOKINGFLIGHTS,method=RequestMethod.POST)
	public String addRoundBooking(@ModelAttribute(AirlineReservationConstants.FLIGHTINFO) FlightInfo flightInfo,@RequestParam("noOfPassengers") int noOfPassengers,@RequestParam("returnDate")String returnDate, @RequestParam("classType") String classType, Model model) throws ServletException
	{
		String view = "";
		try {
			FlightInfo returnFlight=new FlightInfo();
			returnFlight.setDepCity(flightInfo.getArrCity());
			returnFlight.setArrCity(flightInfo.getDepCity());
			SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			Date result1 = formater.parse(returnDate);
			SimpleDateFormat AppDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String temp1 = AppDateFormat.format(result1);
			Date returnDate1 = AppDateFormat.parse(temp1);
			returnFlight.setDepDate(returnDate1);
			int firstSeats = 0;
			int bussSeats = 0;
			if (classType.equalsIgnoreCase(AirlineReservationConstants.FIRSTCLASS)) {
				firstSeats = noOfPassengers;
			} 
			else 
			{
				bussSeats = noOfPassengers;
			}
			this.noOfPassengers=noOfPassengers;
			this.classType=classType;
			flightInfo.setFirstSeats(firstSeats);
			flightInfo.setBussSeats(bussSeats);
			returnFlight.setFirstSeats(firstSeats);
			returnFlight.setBussSeats(bussSeats);
			model.addAttribute(AirlineReservationConstants.CLASSTYPE,classType);
			model.addAttribute(AirlineReservationConstants.NOOFPASSENGERS,noOfPassengers);
			List<FlightInfo> flightList = customerService.getAllFlights(flightInfo);
			List<FlightInfo> returnflightList = customerService.getAllFlights(returnFlight);
			model.addAttribute(AirlineReservationConstants.FLIGHTLIST,flightList);
			model.addAttribute(AirlineReservationConstants.RETURNFLIGHTLIST,returnflightList );
			view = AirlineReservationConstants.ROUNDBOOKINGFLIGHT;

		} catch (Exception e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}

		return view;	

	}


	/**
	 * Method to enable admin update the role of a specific user
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.UPDATEROLEFORM_MAPPING,method=RequestMethod.GET)
	public String updateRoleForm(Model model) throws ServletException
	{
		String view ="";
		try {
			List<UserARS> userList = customerService.getAllCustomers();
			List<String> uMail = new ArrayList<String>();
			for (UserARS val : userList) {
				uMail.add(val.getuMail());
			}
			model.addAttribute(AirlineReservationConstants.UMAIL,uMail);
			model.addAttribute(AirlineReservationConstants.ROLE,new String[]{AirlineReservationConstants.CUSTOMER,AirlineReservationConstants.EXECUTIVE});
			model.addAttribute(AirlineReservationConstants.USERARS,new UserARS());
			view =AirlineReservationConstants.UPDATEROLEFORM_PAGE;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}

	/**
	 * Redirection to the success page after role update
	 * @param userARS
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.UPDATEROLE,method=RequestMethod.POST)
	public String updateRole(@ModelAttribute("userARS") UserARS userARS,Model model) throws ServletException
	{
		String view ="";
		try {
			adminService.updateUserRole(userARS);
			model.addAttribute(AirlineReservationConstants.FLIGHTINFO, new FlightInfo());
			model.addAttribute(AirlineReservationConstants.UMAIL,userARS.getuMail());
			view =AirlineReservationConstants.ROLEUPDATESUCCESS_PAGE;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}
	/**
	 * Redirection to the flight information form
	 * @return String
	 */
	@RequestMapping(value=AirlineReservationConstants.GETFLIGHTINFOFORM,method=RequestMethod.GET)
	public String getFlightInfoForm()
	{
		return AirlineReservationConstants.FLIGHTINFOFORM;
	}
	/**
	 * Fetching the information of a specific flight according to the request made
	 * @param flightNo
	 * @param model
	 * @return String
	 * @throws ServletException
	 */
	@RequestMapping(value=AirlineReservationConstants.GETFLIGHTINFO,method=RequestMethod.POST)
	public String getFlightInfo(@RequestParam(AirlineReservationConstants.FLIGHTNO) int flightNo,Model model) throws ServletException
	{
		String view = "";
		try {
			FlightInfo flightInfo = adminService.getFlightInfo(flightNo);
			model.addAttribute(AirlineReservationConstants.FLIGHTINFO,flightInfo);
			view = AirlineReservationConstants.FLIGHTSTATUS;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}
	/**
	 * Updating the flight information
	 * @param flightInfo
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.UPDATE_MAPPING,method=RequestMethod.POST)
	public String updateFlightInfo(@ModelAttribute(AirlineReservationConstants.FLIGHTINFO) FlightInfo flightInfo,Model model) throws ServletException
	{
		String view = "";
		try {
			adminService.updateFlightInfo(flightInfo);
			model.addAttribute(AirlineReservationConstants.FLIGHTINFO,flightInfo);
			view = AirlineReservationConstants.UPDATE_PAGE;
		} catch (Exception e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}
	/**
	 * Redirection to the booking page
	 * @return String
	 */
	@RequestMapping(value=AirlineReservationConstants.BOOKING_MAPPING,method=RequestMethod.GET)
	public String bookingInfoForm()
	{
		return AirlineReservationConstants.BOOKING_PAGE;
	}
	/**
	 * To fetch a list of all the bookings
	 * @param flightNo
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.BOOKINGINFO_MAPPING,method=RequestMethod.POST)
	public String bookingInfo(@RequestParam(AirlineReservationConstants.FLIGHTNO) int flightNo,Model model) throws ServletException
	{
		String view = "";
		try {
			List<BookingInfo> bookingsList = adminService.getBookingInfoListFlight(flightNo);
			model.addAttribute(AirlineReservationConstants.BOOKINGLIST, bookingsList);
			view = AirlineReservationConstants.BOOKINGINFO;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}
	/**
	 * To display a specific booking according to the ID entered
	 * @param bookingId
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.VIEWBOOKING_MAPPING,method=RequestMethod.POST)
	public String viewBooking(@RequestParam(AirlineReservationConstants.BOOKINGID) String bookingId,Model model) throws ServletException
	{
		String view = "";
		try {
			BookingInfo bookingInfo = customerService.getBookingInfo(bookingId);
			model.addAttribute(AirlineReservationConstants.BOOKINGINFO, bookingInfo);
			view = AirlineReservationConstants.VIEWBOOKING_PAGE;
		} 
		catch (ARSException e) 
		{
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}
	/**
	 * To enable a user logout form the system
	 * @param user
	 * @param session
	 * @param status
	 * @return String
	 */
	@RequestMapping(value=AirlineReservationConstants.LOGOUT,method=RequestMethod.GET)
	public String Logout(@ModelAttribute("user") UserARS user, HttpSession session, SessionStatus status){
		status.setComplete();
		session.removeAttribute(AirlineReservationConstants.USER);
		return "redirect:/index.do";
	}

	/**
	 * Redirection to the update form in case user has forgotten his login password 
	 * @param model
	 * @return
	 */
	@RequestMapping(value=AirlineReservationConstants.FORGOTPASSWORD,method=RequestMethod.GET)
	public String forgotPassword(Model model)
	{
		model.addAttribute(AirlineReservationConstants.USER,new UserARS());
		return AirlineReservationConstants.FORGOTPASSWORDFORM;
	}
	/**
	 * Fetching user data to match with the database and enable reset the same
	 * @param user
	 * @param model
	 * @return String
	 */
	@RequestMapping(value=AirlineReservationConstants.RESETPASSWORD,method=RequestMethod.POST)
	public String resetPassword(@ModelAttribute(AirlineReservationConstants.USER) UserARS user,Model model)
	{	
		String view = "";
		try {
			UserARS userDB = userService.getUserDetails(user);
			model.addAttribute(AirlineReservationConstants.SECURITYQUESTION,new String[]{"Mother's Maiden Name","Pet Dog's Name","Who gave You your First Failing Grade?","City/Town your Nearest sibling live?"});
			model.addAttribute(AirlineReservationConstants.USER,user);
			view="forgotpasswordForm";
		} catch (ARSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return view;
	}
	/**
	 * Reseting user password and performing the required validations
	 * @param user
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.RESETPASS,method=RequestMethod.POST)
	public String resetPass(@ModelAttribute(AirlineReservationConstants.USER) UserARS user,Model model) throws ServletException
	{	String view = "" ; 		
	try {
		UserARS userDB = userService.getUserDetails(user);
		if(((userDB.getSecurityQuestion().equals(user.getSecurityQuestion()))&&(userDB.getSecurityAnswer().equals(user.getSecurityAnswer())))){
			String matcher = AirlineReservationConstants.TRUE;
			model.addAttribute(AirlineReservationConstants.MATCHER,matcher);
			model.addAttribute(AirlineReservationConstants.USER,user);
			view=AirlineReservationConstants.FORGOTPASSWORDFORM;
		}else{
			user.setSecurityQuestion(null);
			user.setSecurityAnswer(null);
			model.addAttribute(AirlineReservationConstants.SECURITYQUESTION,new String[]{"Mother's Maiden Name","Pet Dog's Name","Who gave You your First Failing Grade?","City/Town your Nearest sibling live?"});
			model.addAttribute(AirlineReservationConstants.USER,user);
			model.addAttribute(AirlineReservationConstants.ERROR,"Security Question/Answer not VaLid");
			view=AirlineReservationConstants.FORGOTPASSWORDFORM;
		}
	} catch (ARSException e) {
		myLogger.error(e.getMessage());
		throw new ServletException(e.getMessage(),e);
	}
	return view;
	}

	/**
	 * Redirection to the acknowledgment page after successful password update
	 * @param user
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.UPDATEPASSWORD,method=RequestMethod.POST)
	public String updatePassword(@ModelAttribute(AirlineReservationConstants.USER) UserARS user,Model model) throws ServletException
	{	String view = "" ; 		
	try {
		userService.updatePassword(user);
		model.addAttribute("success","Password Updated Successfully");
		view = AirlineReservationConstants.PASSWORDUPDATESUCCESS;
	} catch (ARSException e) {
		myLogger.error(e.getMessage());
		throw new ServletException(e.getMessage(),e);
	}
	return view;
	}


	/**
	 * Redirection to the round trip booking form
	 * @param model
	 * @param flightDate
	 * @param returnFlightDate
	 * @param noOfPassengers
	 * @param classType
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.ADDROUNDBOOKINGFORM,method=RequestMethod.POST)
	public String  addRoundBookingForm(Model model, @RequestParam(AirlineReservationConstants.FLIGHTDATE) String flightDate,@RequestParam(AirlineReservationConstants.RETURNFLIGHTDATE) String returnFlightDate,@RequestParam("noOfPassengers") int noOfPassengers,@RequestParam("classType") String classType) throws ServletException
	{
		String view="";
		double totalFare = 0;
		try {
			FlightInfo flight = adminService.getFlightInfoReturn(flightDate);
			FlightInfo returnFlight = adminService.getFlightInfoReturn(returnFlightDate);
			if(this.classType.equals(AirlineReservationConstants.CLASSTYPE)){
				totalFare += this.noOfPassengers * flight.getFirstSeatfare();
				totalFare+=this.noOfPassengers * returnFlight.getFirstSeatfare();
			}else{
				totalFare += this.noOfPassengers * flight.getBussSeatsFare();
				totalFare+=this.noOfPassengers * returnFlight.getBussSeatsFare();
			}
			List<UserARS> userList = customerService.getAllCustomers();
			List<String> uMail = new ArrayList<String>();
			for (UserARS val : userList) {
				uMail.add(val.getuMail());
			}
			model.addAttribute(AirlineReservationConstants.UMAIL,uMail);
			model.addAttribute(AirlineReservationConstants.TOTALFARE,totalFare);
			model.addAttribute(AirlineReservationConstants.NOOFPASSENGERS,noOfPassengers);
			model.addAttribute(AirlineReservationConstants.FLIGHT,flight);
			model.addAttribute(AirlineReservationConstants.RETURNFLIGHT,returnFlight);
			model.addAttribute(AirlineReservationConstants.BOOKINGINFO,new BookingInfo());
			view=AirlineReservationConstants.ROUNDBOOKING;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}
	/**
	 * To enable a user book flight for a round trip
	 * @param bookingInfo
	 * @param rdate
	 * @param returnFlightDate
	 * @param model
	 * @return String
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.ADDROUNDBOOKING,method=RequestMethod.POST)
	public String addRoundBooking(@ModelAttribute(AirlineReservationConstants.BOOKINGINFO) BookingInfo bookingInfo,@RequestParam(AirlineReservationConstants.RETURNDATE) String rdate,@RequestParam(AirlineReservationConstants.RETURNFLIGHTDATE) String returnFlightDate, Model model) throws ServletException
	{

		String view = "";
		try {
			SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			Date result = formater.parse(rdate);
			SimpleDateFormat AppDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String temp = AppDateFormat.format(result);
			Date returnDate = AppDateFormat.parse(temp);
			FlightInfo flightInfo = adminService.getFlightInfoReturn(bookingInfo.getFlightInfo().getFlightDate());
			FlightInfo returnFlightInfo = adminService.getFlightInfoReturn(returnFlightDate);

			BookingInfo returnBooking = new BookingInfo(); 
			FlightInfo returnFlight = new FlightInfo();
			returnBooking.setUser(bookingInfo.getUser());
			returnBooking.setClass_Type(bookingInfo.getClass_Type());
			returnBooking.setCreditCardInfo(bookingInfo.getCreditCardInfo());
			returnBooking.setNo_of_passengers(bookingInfo.getNo_of_passengers());
			returnBooking.setTotalFare(bookingInfo.getTotalFare());
			returnFlight.setFlightDate(returnFlightDate);
			returnBooking.setFlightInfo(returnFlight);
			returnBooking.setFlightNo(returnFlightInfo.getFlightNo());
			returnBooking.setSrcCity(returnFlightInfo.getDepCity());
			returnBooking.setDestCity(returnFlightInfo.getArrCity());
			returnBooking.setDeptDate(returnDate);
			int id = customerService.bookingId();
			String bookingId = flightInfo.getAirLine() + id;
			String returnBookingId = returnFlightInfo.getAirLine() + id +"RETURN";
			bookingInfo.setBooking_Id(bookingId);
			returnBooking.setBooking_Id(returnBookingId);
			customerService.addBookingInfo(bookingInfo);
			customerService.addBookingInfo(returnBooking);
			model.addAttribute(AirlineReservationConstants.BOOKINGINFO,bookingInfo);
			model.addAttribute(AirlineReservationConstants.RETURNBOOKING,returnBooking);			
			view=AirlineReservationConstants.BOOKINGSUCCESS;


		} catch (ParseException | ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}


		return view;	
	}
	/**
	 * To cancel a booking by its booking ID
	 * @param bookingId
	 * @param model
	 * @return
	 * @throws ServletException 
	 */
	@RequestMapping(value=AirlineReservationConstants.CANCELBOOKING,method=RequestMethod.POST)
	public String cancelBooking(@RequestParam(AirlineReservationConstants.BOOKINGID) String bookingId,Model model) throws ServletException
	{
		String view = "";
		try {
			BookingInfo bookingInfo = customerService.getBookingInfo(bookingId);
			customerService.deleteBooking(bookingInfo);
			model.addAttribute(AirlineReservationConstants.BOOKINGID,bookingId);
			view = AirlineReservationConstants.CANCELSUCCESS;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}


	/**
	 * Page to display a list of all the bookings for a specific user mail ID
	 * @param uMail
	 * @param model
	 * @return String
	 * @throws ServletException
	 */
	@RequestMapping(value=AirlineReservationConstants.VIEWBOOKINGS_MAPPING,method=RequestMethod.GET)
	public String viewBookings(@RequestParam(AirlineReservationConstants.UMAIL) String uMail,Model model) throws ServletException
	{
		String view = "";
		try {
			List<BookingInfo> bookingList = customerService.getAllBookings(uMail);
			model.addAttribute(AirlineReservationConstants.BOOKINGLIST,bookingList);
			view=AirlineReservationConstants.ALLBOOKINGS;
		} catch (ARSException e) {
			myLogger.error(e.getMessage());
			throw new ServletException(e.getMessage(),e);
		}
		return view;
	}
	/**
	 * Enabling an executive to book a flight ticket on behalf of somebody else
	 * @param cust
	 * @param model
	 * @return String
	 */
	@RequestMapping(value=AirlineReservationConstants.EXECADDBOOKING,method=RequestMethod.GET)
	public String execAddBooking(@ModelAttribute(AirlineReservationConstants.CUSTOMER) UserARS cust,Model model)
	{
		model.addAttribute(AirlineReservationConstants.FLIGHTINFO, new FlightInfo());
		model.addAttribute("depCity",new String[]{"Amritsar","Bangalore","Pune","Kolkata","Mumbai","Himachal","Ranchi","Delhi","Hyderabad"});
		model.addAttribute("arrCity",new String[]{"Amritsar","Bangalore","Pune","Kolkata","Mumbai","Himachal","Ranchi","Delhi","Hyderabad"});
		return AirlineReservationConstants.EXECADDBOOKING_PAGE;	
	}
	//Redirection to the bookings page
	@RequestMapping(value=AirlineReservationConstants.BOOKINGS_MAPPING,method=RequestMethod.GET)
	public String bookings()
	{
		return AirlineReservationConstants.BOOKINGS_PAGE;	
	}
	@RequestMapping(value=AirlineReservationConstants.LOCATIONS_MAPPING,method=RequestMethod.GET)
	public String locations()
	{
		return AirlineReservationConstants.LOCATIONS_PAGE;	
	}
	@RequestMapping(value=AirlineReservationConstants.CONTACT_MAPPING,method=RequestMethod.GET)
	public String contactUs()
	{
		return AirlineReservationConstants.CONTACT_PAGE;	
	}
}
