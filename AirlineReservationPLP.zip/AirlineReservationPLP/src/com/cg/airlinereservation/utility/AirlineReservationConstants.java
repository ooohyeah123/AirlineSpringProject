/**
 * 
 */
package com.cg.airlinereservation.utility;

/**
 ***********************************************************************************
 * File:        AirlineReservationConstants.java
 * Package:     com.cg.airlinereservation.utility
 * Desc:        a class for defining all constants used
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
 */

public class AirlineReservationConstants {

	public static final String USER = "user";
	public static final String INDEX_MAPPING = "/index";
	public static final String USERNAME = "userName";
	public static final String FLIGHTINFO = "flightInfo";
	public static final String INDEX_PAGE = "index";
	public static final String LOGIN_FORM = "/loginForm";
	public static final String LOGIN = "login";
	public static final String REGISTERFORM = "/registerForm";
	public static final String SECURITYQUESTION = "securityQuestion";
	public static final String REGISTER = "register";
	public static final String CUSTOMER = "CUSTOMER";
	public static final String GETALLFLIGHTS = "/getAllFlights";
	public static final String FIRSTCLASS = "FirstClass";
	public static final String FLIGHTS = "flights";
	public static final String FLIGHTLIST = "flightList";
	public static final String ADDBOOKINGFORM = "/addBookingForm";
	public static final String FLIGHTDATE = "flightDate";
	public static final String CLASSTYPE = "classType";
	public static final String NOOFPASSENGERS = "noOfPassengers";
	public static final String UMAIL = "uMail";
	public static final String TOTALFARE = "totalFare";
	public static final String BOOKINGINFO = "bookingInfo";
	public static final String BOOKINGINFO_MAPPING = "/bookingInfo";
	public static final String BOOKINGFLIGHT = "bookingFlight";
	public static final String ADDBOOKING = "/addBooking";
	public static final String BOOKINGSUCCESS = "bookingSuccess";
	public static final String ROUNDBOOKINGFLIGHTS = "roundBookingFlights";
	public static final String RETURNDATE = "returnDate";
	public static final String ROUNDBOOKINGFLIGHT = "roundBookingFlight";
	public static final String RETURNFLIGHTLIST = "returnFlightList";
	public static final String UPDATEROLEFORM_MAPPING = "/updateRoleForm";
	public static final String UPDATEROLE = "/updateRole";
	public static final String GETFLIGHTINFOFORM = "/getFlightInfoForm";
	public static final String FLIGHTINFOFORM = "flightInfoForm";
	public static final String GETFLIGHTINFO = "/getFlightInfo";
	public static final String UPDATEROLEFORM_PAGE = "updateRoleForm";
	public static final String UPDATE_MAPPING = "/updateFlightInfo";
	public static final String UPDATE_PAGE = "updatedFlightInfo";
	public static final String BOOKING_MAPPING = "/bookingInfoForm";
	public static final String BOOKING_PAGE = "bookingInfoForm";
	public static final String BOOKINGLIST = "bookingList";
	public static final String ROLE = "roles";
	public static final String ERROR = "error";
	public static final String USERARS = "userARS";
	public static final String FLIGHTSTATUS = "FlightStatus";
	public static final String FLIGHT = "flight";
	public static final String FLIGHTNO = "flightNo";
	public static final String EXECUTIVE = "EXECUTIVE";
	public static final String LOGOUT = "/logout";
	public static final String VIEWBOOKING = "/viewBooking";
	public static final String FORGOTPASSWORD = "/forgotPassword";
	public static final String FORGOTPASSWORDFORM = "forgotpasswordForm";
	public static final String RESETPASSWORD = "/resetPassword";
	public static final String RESETPASS = "/resetPass";
	public static final String TRUE = "true";
	public static final String MATCHER = "matcher";
	public static final String UPDATEPASSWORD = "/updatePassword";
	public static final String PASSWORDUPDATESUCCESS = "passwordUpdateSuccess";
	public static final String SUCCESS = "success";
	public static final String RETURNFLIGHT = "returnFlight";
	public static final String ADDROUNDBOOKINGFORM = "/addRoundBookingForm";
	public static final String RETURNFLIGHTDATE = "returnFlightDate";
	public static final String ADDROUNDBOOKING = "/addRoundBooking";
	public static final String RETURN = "RETURN";
	public static final String RETURNBOOKING = "returnBooking";
	public static final String CANCELBOOKING = "/cancelBooking";
	public static final String BOOKINGID = "bookingId";
	public static final String CANCELSUCCESS = "cancelSuccess";
	public static final String VIEWBOOKING_MAPPING = "/viewBooking";
	public static final String VIEWBOOKING_PAGE = "viewBooking";
	public static final String VIEWBOOKINGS_MAPPING = "/viewBookings";
	public static final String ALLBOOKINGS = "allBookings";
	public static final String ROUNDBOOKING = "roundBooking";
	public static final String EXECADDBOOKING = "/execAddBooking";
	public static final String EXECADDBOOKING_PAGE = "execAddBooking";
	public static final String ROLEUPDATESUCCESS_PAGE = "roleUpdateSuccess";
	public static final String BOOKINGS_MAPPING = "/bookings";
	public static final String BOOKINGS_PAGE = "bookings";
	public static final String LOCATIONS_MAPPING = "/locations";
	public static final String LOCATIONS_PAGE = "locations";
	public static final String CONTACT_MAPPING = "/contactUs";
	public static final String CONTACT_PAGE = "contactUs";
	
}

