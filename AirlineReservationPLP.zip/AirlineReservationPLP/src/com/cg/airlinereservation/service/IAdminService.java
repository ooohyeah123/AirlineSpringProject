/**
 ***********************************************************************************
 * File:        IAdminService.java
 * Package:     com.cg.airlinereservation.service
 * Desc:        an interface for the admin
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.service;

import java.util.List;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;

public interface IAdminService 
{
	/**
	 * to get a specific flight info
	 * @param flightno
	 * @return FlightInfo
	 * @throws ARSException
	 */
	public FlightInfo getFlightInfo(int flightno) throws ARSException;
	
	/**
	 * to update the info of a flight
	 * @param flightInfo
	 * @throws ARSException
	 */
	public void updateFlightInfo(FlightInfo flightInfo) throws ARSException;
	
	/**
	 * to fetch the list of all bookings
	 * @param flightInfo
	 * @return List
	 * @throws ARSException
	 */
	public List<BookingInfo> getBookingInfoListFlight(int flightInfo) throws ARSException; 
	
	/**
	 * to fetch details of return flight while making a round trip booking 
	 * @param flightDate
	 * @return FlightInfo
	 * @throws ARSException
	 */
	public FlightInfo getFlightInfoReturn(String flightDate)throws ARSException;
	
	/**
	 * to update user role
	 * @param user
	 * @throws ARSException
	 */
	void updateUserRole(UserARS user) throws ARSException;
}
