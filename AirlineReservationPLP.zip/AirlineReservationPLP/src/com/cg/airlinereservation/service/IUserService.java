
package com.cg.airlinereservation.service;

import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;


/**
 ***********************************************************************************
 * File:        IUserService.java
 * Package:     com.cg.airlinereservation.service
 * Desc:        an interface for user
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
 */

public interface IUserService {
	/**
	 * get user details from database
	 * @param userARS
	 * @return
	 * @throws ARSException
	 */
	public UserARS getUser(UserARS userARS) throws ARSException;

	/**
	 * to add a user
	 * @param userARS
	 * @throws ARSException
	 */
	public void addUser(UserARS userARS) throws ARSException;

	/**
	 * to delete a user from the system
	 * @param userARS
	 * @throws ARSException
	 */
	public void removeUser(UserARS userARS) throws ARSException;

	/**
	 * to update a user
	 * @param userARS
	 * @throws ARSException
	 */
	public void updateUser(UserARS userARS) throws ARSException;

	/**
	 * to get details of a user
	 * @param user
	 * @return
	 * @throws ARSException
	 */
	public UserARS getUserDetails(UserARS user) throws ARSException;

	/**
	 * to update password of a user
	 * @param paramUserARS
	 * @throws ARSException
	 */
	public void updatePassword(UserARS paramUserARS) throws ARSException;
}
