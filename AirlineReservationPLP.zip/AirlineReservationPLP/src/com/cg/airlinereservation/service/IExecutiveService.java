/**
 ***********************************************************************************
 * File:        IExecutiveService.java
 * Package:     com.cg.airlinereservation.service
 * Desc:        an interface for the executive service
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.service;

import java.util.List;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.exception.ARSException;

public interface IExecutiveService {
	
	/**
	 * To display a particular booking
	 * @param flightno
	 * @return
	 * @throws ARSException
	 */
	public List<BookingInfo> showBookings(int flightno) throws ARSException;

}
