/**
 ***********************************************************************************
 * File:        CustomerServiceImpl.java
 * Package:     com.cg.airlinereservation.service
 * Desc:        Server Unit to handle all request from users
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.service;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.airlinereservation.dao.ICustomerRepository;
import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;
@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerRepository custRepository;
	
	/* (non-Javadoc)
	 * to add booking information
	 * @see com.cg.airlinereservation.service.ICustomerService#addBookingInfo(com.cg.airlinereservation.entities.BookingInfo)
	 */
	@Override
	public void addBookingInfo(BookingInfo bookingInfo) throws ARSException {
		custRepository.addBookingInfo(bookingInfo);
	}

	

	/* (non-Javadoc)
	 * to delete booking information
	 * @see com.cg.airlinereservation.service.ICustomerService#deleteBooking(com.cg.airlinereservation.entities.BookingInfo)
	 */
	@Override
	public void deleteBooking(BookingInfo bookingInfo) throws ARSException {
		custRepository.deleteBooking(bookingInfo);

	}

	/* (non-Javadoc)
	 * to get the list of all flights
	 * @see com.cg.airlinereservation.service.ICustomerService#getAllFlights(com.cg.airlinereservation.entities.FlightInfo)
	 */
	@Override
	public List<FlightInfo> getAllFlights(FlightInfo flightInfo)throws ARSException {
		return custRepository.getAllFlights(flightInfo);
	}

	/* (non-Javadoc)
	 * generating booking id
	 * @see com.cg.airlinereservation.service.ICustomerService#bookingId()
	 */
	@Override
	public int bookingId() throws ARSException {
		// TODO Auto-generated method stub
		return custRepository.bookingId();
	}

	/* (non-Javadoc)
	 * to get booking information using booking id
	 * @see com.cg.airlinereservation.service.ICustomerService#getBookingInfo(java.lang.String)
	 */
	@Override
	public BookingInfo getBookingInfo(String bookingId) throws ARSException {
		return custRepository.getBookingInfo(bookingId);
	}

	/* (non-Javadoc)
	 * to get all bookings using user mail
	 * @see com.cg.airlinereservation.service.ICustomerService#getAllBookings(java.lang.String)
	 */
	@Override
	public List<BookingInfo> getAllBookings(String uMail) throws ARSException {
		return custRepository.getAllBookings(uMail);
	}

	/* (non-Javadoc)
	 * to get the list of all customers
	 * @see com.cg.airlinereservation.service.ICustomerService#getAllCustomers()
	 */
	@Override
	public List<UserARS> getAllCustomers() throws ARSException {
		return custRepository.getAllCustomers();
	}

	/* (non-Javadoc)
	 * to get the customer details
	 * @see com.cg.airlinereservation.service.ICustomerService#getCustomerDetails(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public UserARS getCustomerDetails(UserARS customer) throws ARSException {
		// TODO Auto-generated method stub
		return custRepository.getCustomerDetails(customer);
	}

}
