/**
 ***********************************************************************************
 * File:        FlightInfo.java
 * Package:     com.cg.airlinereservation.entities
 * Desc:        Server Unit to handle all request from users
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
 */
package com.cg.airlinereservation.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;


@Entity(name="flightInfo")
@Table(name="flightInfo")
public class FlightInfo
implements Serializable
{
	private static final long serialVersionUID = 1L;

	private int flightNo;
	private String airLine;
	private String depCity;
	private String arrCity;
	private Date depDate;
	private Date arrDate;
	private String depTime;
	private String arrTime;
	private int firstSeats;
	private float firstSeatfare;
	private int bussSeats;
	private float bussSeatsFare;
	private String flightDate; 
	private Set<BookingInfo> bookingList;


	/*
	 * Generation of all getters and setters for respective fields 
	 */

	@OneToMany(mappedBy="flightInfo", fetch=FetchType.LAZY) 
	public Set<BookingInfo> getBookingList() {
		return bookingList;
	}

	public void setBookingList(Set<BookingInfo> bookingList) {
		this.bookingList = bookingList;
	}

	@Column(name="flightNo")
	public int getFlightNo()
	{
		return flightNo;
	}

	public void setFlightNo(int flightNo)
	{
		this.flightNo = flightNo;
	}

	@Column(name="airline")
	public String getAirLine()
	{
		return airLine;
	}

	public void setAirLine(String airLine)
	{
		this.airLine = airLine;
	}

	@Column(name="dep_city")
	public String getDepCity()
	{
		return depCity;
	}

	public void setDepCity(String depCity)
	{
		this.depCity = depCity;
	}

	@Column(name="arr_city")
	public String getArrCity()
	{
		return arrCity;
	}

	public void setArrCity(String arrCity)
	{
		this.arrCity = arrCity;
	}
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Column(name="dep_date")
	public Date getDepDate()
	{
		return depDate;
	}

	public void setDepDate(Date depDate)
	{
		this.depDate = depDate;
	}
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Column(name="arr_date")
	public Date getArrDate()
	{
		return arrDate;
	}

	public void setArrDate(Date arrDate)
	{
		this.arrDate = arrDate;
	}

	@Column(name="dep_time")
	public String getDepTime()
	{
		return depTime;
	}

	public void setDepTime(String depTime)
	{
		this.depTime = depTime;
	}

	@Column(name="arr_time")
	public String getArrTime()
	{
		return arrTime;
	}

	public void setArrTime(String arrTime)
	{
		this.arrTime = arrTime;
	}
	@Column(name="FirstSeats")
	public int getFirstSeats()
	{
		return firstSeats;
	}

	public void setFirstSeats(int firstSeats)
	{
		this.firstSeats = firstSeats;
	}
	@Column(name="FirstSeatFare")
	public float getFirstSeatfare()
	{
		return firstSeatfare;
	}

	public void setFirstSeatfare(float firstSeatfare)
	{
		this.firstSeatfare = firstSeatfare;
	}
	@Column(name="bussSeats")
	public int getBussSeats()
	{
		return bussSeats;
	}

	public void setBussSeats(int bussSeats)
	{
		this.bussSeats = bussSeats;
	}
	@Column(name="bussSeatsFare")
	public float getBussSeatsFare()
	{
		return bussSeatsFare;
	}

	public void setBussSeatsFare(float bussSeatsFare)
	{
		this.bussSeatsFare = bussSeatsFare;
	}
	@Id
	@Column(name="flightDate")
	public String getFlightDate()
	{
		return flightDate;
	}

	public void setFlightDate(String flightDate)
	{
		this.flightDate = flightDate;
	}

	public FlightInfo() {}

	/**
	 * Parameterized constructor 
	 * @param flightNo
	 * @param airLine
	 * @param depCity
	 * @param arrCity
	 * @param depDate
	 * @param arrDate
	 * @param depTime
	 * @param arrTime
	 * @param firstSeats
	 * @param firstSeatfare
	 * @param bussSeats
	 * @param bussSeatsFare
	 */
	public FlightInfo(int flightNo, String airLine, String depCity, String arrCity, Date depDate, Date arrDate, String depTime, String arrTime, int firstSeats, float firstSeatfare, int bussSeats, float bussSeatsFare)
	{
		this.flightNo = flightNo;
		this.airLine = airLine;
		this.depCity = depCity;
		this.arrCity = arrCity;
		this.depDate = depDate;
		this.arrDate = arrDate;
		this.depTime = depTime;
		this.arrTime = arrTime;
		this.firstSeats = firstSeats;
		this.firstSeatfare = firstSeatfare;
		this.bussSeats = bussSeats;
		this.bussSeatsFare = bussSeatsFare;
		this.flightDate = (flightNo +""+ depDate.getDate() + (depDate.getMonth() + 1) + (depDate.getYear() + 1900));
	}

	/* (non-Javadoc)
	 * Generation of a toString()
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		return 

				"FlightInfo [flightNo=" + this.flightNo + ", airLine=" + this.airLine + ", depCity=" + this.depCity + ", arrCity=" + this.arrCity + ", depDate=" + this.depDate + ", arrDate=" + this.arrDate + ", depTime=" + this.depTime + ", arrTime=" + this.arrTime + ", firstSeats=" + this.firstSeats + ", firstSeatfare=" + this.firstSeatfare + ", bussSeats=" + this.bussSeats + ", bussSeatsFare=" + this.bussSeatsFare + ", FlightDate=" + this.flightDate + "]";
	}
}
