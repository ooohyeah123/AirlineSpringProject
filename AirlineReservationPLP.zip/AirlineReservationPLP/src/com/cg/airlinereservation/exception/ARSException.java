/**
 ***********************************************************************************
 * File:        ARSException.java
 * Package:     com.cg.airlinereservation.exception
 * Desc:        to deal with user-related exception
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.exception;

public class ARSException extends Exception{

	/**
	 * Unique serisl version ID
	 */
	private static final long serialVersionUID = 1L;

	public ARSException() {
		super();
	}

	/*
	 * Generation of superclass constructor 
	 */
	public ARSException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public ARSException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public ARSException(String arg0) {
		super(arg0);
	}

	public ARSException(Throwable arg0) {
		super(arg0);
	}
	
}
