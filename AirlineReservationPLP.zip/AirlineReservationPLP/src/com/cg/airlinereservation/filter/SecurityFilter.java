package com.cg.airlinereservation.filter;

import java.io.IOException;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.airlinereservation.logFile.LogInfo;

/**
 ***********************************************************************************
 * File:        SecurityFilter.java
 * Package:     com.cg.airlinereservation.filter
 * Desc:        to apply filters into the system for security reasons
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/

/**
 * Servlet Filter implementation class SecurityFilter
 */
@WebFilter("/*")
public class SecurityFilter implements Filter {
	static Logger myLogger;

	/**
	 * Default constructor. 
	 */
	public SecurityFilter() {
		myLogger =  Logger.getLogger(LogInfo.class);

	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * Method to perform the filtering task
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		PropertyConfigurator.configure("log4j.properties");

		System.err.println("this is filter");
		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse res=(HttpServletResponse)response;
		HttpSession session= req.getSession();
		String uri=req.getRequestURI();
		System.out.println(uri);
		String action=uri.substring(uri.lastIndexOf("/"),uri.length());
		System.out.println(action);

		String hostAdd=req.getRemoteAddr();
		String tarAdd=req.getRequestURI();
		Date indate=new Date();
		System.out.println("HOST Address:"+hostAdd);
		System.out.println("Target Address:"+tarAdd);
		System.out.println("Log In time:"+indate); 
		myLogger.info("HOST Address:"+hostAdd);
		if(session.getAttribute("userName")!=null  || uri.endsWith("login.do")|| uri.endsWith("AirlineReservationSystem_login.jsp")|| uri.endsWith("AirlineReservationSystem_register.jsp")|| uri.endsWith("registerForm.do")|| uri.endsWith("register.do")||uri.endsWith("forgotPassword.do")||uri.endsWith("resetPassword.do")||uri.endsWith("resetPass.do")||uri.endsWith("updatePassword.do")||uri.endsWith("AirlineReservationSystem_forgotpasswordForm.jsp")||uri.endsWith("loginForm.do")){

			chain.doFilter(request, response);
			Date outdate=new Date();
			System.out.println("Log Out Time:"+outdate);
		}
		else if(uri.endsWith("AirlineReservationSystem_locations.jsp"))
		{
			chain.doFilter(request, response);
		}
		else if(uri.endsWith(".css"))
		{
			chain.doFilter(request, response);
		}
		else if(uri.endsWith(".js"))
		{
			chain.doFilter(request, response);
		}
		else if(uri.endsWith(".jpg"))
		{
			chain.doFilter(request, response);
		}
		else if(uri.endsWith(".png"))
		{
			chain.doFilter(request, response);
		}
		else if(uri.endsWith(".ico"))
		{
			chain.doFilter(request, response);
		}
		else if(uri.endsWith(".woff"))
		{
			chain.doFilter(request, response);
		}
		else if(uri.endsWith(".ttf"))
		{
			chain.doFilter(request, response);
		}

		else{
			res.sendRedirect("loginForm.do");

		}
	}



	/**
	 * init() for initialization
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {

	}

}
