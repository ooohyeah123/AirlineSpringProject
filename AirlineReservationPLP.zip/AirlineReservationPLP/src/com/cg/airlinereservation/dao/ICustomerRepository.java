/**
 ***********************************************************************************
 * File:        ICustomerRepository.java
 * Package:     com.cg.airlinereservation.dao
 * Desc:        Server Unit to handle all request from users
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
 */
package com.cg.airlinereservation.dao;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;

import java.util.Date;
import java.util.List;

public interface ICustomerRepository
{

	public BookingInfo getBookingInfo(String bookingId)throws ARSException ;

	/**
	 * Method to add a new booking
	 * @param paramBookingInfo
	 * @throws ARSException
	 */
	public void addBookingInfo(BookingInfo paramBookingInfo)
			throws ARSException;

	/**
	 * Method to delete a specific booking
	 * @param paramBookingInfo
	 * @throws ARSException
	 */
	public void deleteBooking(BookingInfo paramBookingInfo)
			throws ARSException;

	/**
	 * Method to fetch an auto-generated bookingID form the database
	 * @return int
	 * @throws ARSException
	 */
	public int bookingId()
			throws ARSException;

	/**
	 * Method to fetch all flights for a specific search
	 * @param flight
	 * @return List
	 * @throws ARSException
	 */
	List<FlightInfo> getAllFlights(FlightInfo flight)throws ARSException;
	
	
	/**
	 * Method to fetch all the bookings
	 * @param uMail
	 * @return List
	 * @throws ARSException
	 */
	List<BookingInfo> getAllBookings(String uMail)
			throws ARSException;

	/**
	 * Method to fetch all customers of the system
	 * @return List
	 * @throws ARSException
	 */
	public List<UserARS> getAllCustomers()
			throws ARSException;

	/**
	 * Method to fetch the details of a specific customer
	 * @param customer
	 * @return UserARS
	 * @throws ARSException
	 */
	public UserARS getCustomerDetails(UserARS customer) throws ARSException;
}
