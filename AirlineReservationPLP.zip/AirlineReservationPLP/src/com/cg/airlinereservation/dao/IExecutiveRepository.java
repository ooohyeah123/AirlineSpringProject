/**
 ***********************************************************************************
 * File:        IExecutiveRepository.java
 * Package:     com.cg.airlinereservation.dao
 * Desc:       an interface to exceutiveRepository
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.dao;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.exception.ARSException;
import java.util.List;

public abstract interface IExecutiveRepository
{
  /**
   * Method to display all the bookings done
 * @param paramInt
 * @return
 * @throws ARSException
 */
public abstract List<BookingInfo> showBookings(int paramInt)
    throws ARSException;
}
