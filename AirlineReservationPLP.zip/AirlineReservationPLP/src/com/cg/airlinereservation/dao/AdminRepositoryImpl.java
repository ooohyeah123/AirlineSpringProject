/**
 ***********************************************************************************
 * File:        AdminRepositoryImpl.java
 * Package:     com.cg.airlinereservation.dao
 * Desc:        Admin Repository to handle administrative database requests
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
*/
package com.cg.airlinereservation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;
import com.cg.airlinereservation.logFile.LogInfo;

@Repository
public class AdminRepositoryImpl implements IAdminRepository {
	
	private static Logger myLogger;
	@PersistenceContext
	private EntityManager manager;

	
	/*
	 * Constructor to Initialize Logger
	 */
	public AdminRepositoryImpl() {
		myLogger =  Logger.getLogger(LogInfo.class);
	}
	/* (non-Javadoc)
	 * to get the information of a particular flight
	 * @see com.cg.airlinereservation.dao.IAdminRepository#getFlightInfo(int)
	 */
	
	@Override
	public FlightInfo getFlightInfo(int flightNo) throws ARSException {
		
		TypedQuery<FlightInfo> query = manager.createQuery("SELECT f FROM flightInfo f where flightNo = :pflightNo ", FlightInfo.class);
		query.setParameter("pflightNo", flightNo);
		myLogger.info("Flight Fetching Succesful");
		FlightInfo getFlight = query.getSingleResult();
		if(getFlight == null){
			throw new ARSException("No Flight Found");
		}
		return getFlight;
	}

	/* (non-Javadoc)
	 * to update the information of a particular flight
	 * @see com.cg.airlinereservation.dao.IAdminRepository#updateFlightInfo(com.cg.airlinereservation.entities.FlightInfo)
	 */
	@Override
	public void updateFlightInfo(FlightInfo flightInfo)throws ARSException {
		FlightInfo flightInfoDB = manager.find(FlightInfo.class, flightInfo.getFlightDate());
		flightInfoDB.setAirLine(flightInfo.getAirLine());
		flightInfoDB.setArrCity(flightInfo.getArrCity());
		flightInfoDB.setArrDate(flightInfo.getArrDate());
		flightInfoDB.setArrTime(flightInfo.getArrTime());
		flightInfoDB.setBussSeats(flightInfo.getBussSeats());
		flightInfoDB.setBussSeatsFare(flightInfo.getBussSeatsFare());
		flightInfoDB.setDepCity(flightInfo.getDepCity());
		flightInfoDB.setDepDate(flightInfo.getDepDate());
		flightInfoDB.setDepTime(flightInfo.getDepTime());
		flightInfoDB.setFirstSeatfare(flightInfo.getFirstSeatfare());
		flightInfoDB.setFirstSeats(flightInfo.getFirstSeats());
		flightInfoDB.setFlightDate(flightInfo.getFlightDate());
		flightInfoDB.setFlightNo(flightInfo.getFlightNo());
	}

	

	/* (non-Javadoc)
	 * to get the information of a booking list
	 * @see com.cg.airlinereservation.dao.IAdminRepository#getBookingInfoListFlight(int)
	 */
	@Override
	public List<BookingInfo> getBookingInfoListFlight(int flightNo) throws ARSException {
		TypedQuery<BookingInfo> query = manager.createQuery("SELECT b FROM bookingInfo b where flightNo = :pflightNo ", BookingInfo.class);
		query.setParameter("pflightNo", flightNo);
		List<BookingInfo> bookingList =  query.getResultList();
		if(bookingList.isEmpty()){
			throw new ARSException("No Flights Found");
		}
		return bookingList;
		
	}

	/* (non-Javadoc)
	 * to update the role of user
	 * @see com.cg.airlinereservation.dao.IAdminRepository#updateUserRole(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public void updateUserRole(UserARS user)
			throws ARSException {
		UserARS userDB = manager.find(UserARS.class, user.getuMail());
		if(userDB != null){
			userDB.setRole(user.getRole());
			myLogger.info("User role Successfully changed");
		}
		
		
	}

	/* (non-Javadoc)
	 * to get the information of a flight using flightDate(primary key)
	 * @see com.cg.airlinereservation.dao.IAdminRepository#getFlightInfoReturn(java.lang.String)
	 */
	@Override
	public FlightInfo getFlightInfoReturn(String flightDate)throws ARSException {
		FlightInfo flight = manager.find(FlightInfo.class, flightDate);
		myLogger.info(flight);
		return flight;
	}

}
