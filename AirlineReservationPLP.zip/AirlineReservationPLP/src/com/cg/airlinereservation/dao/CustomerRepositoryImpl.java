/**
 ***********************************************************************************
 * File:        CustomerRepositoryImpl.java
 * Package:     com.cg.airlinereservation.dao
 * Desc:        to get details about flight,to book a flight,to cancel it,to see the availability of flights etc.
 * Version:     1.0
 * Modifications:
 * Author:            Date:          Change Description:
 * Group 1     		21-01-2017     		Initial Version
 ***********************************************************************************
 */
package com.cg.airlinereservation.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.airlinereservation.entities.BookingInfo;
import com.cg.airlinereservation.entities.FlightInfo;
import com.cg.airlinereservation.entities.UserARS;
import com.cg.airlinereservation.exception.ARSException;
import com.cg.airlinereservation.logFile.LogInfo;

@Repository
public class CustomerRepositoryImpl implements ICustomerRepository {


	@PersistenceContext
	private EntityManager manager;

	private static Logger myLogger;
	
	/*
	 * Default constructor for CustomerRepositoryImpl
	 */
	public CustomerRepositoryImpl() {
		myLogger =  Logger.getLogger(LogInfo.class);
	}

	
	/* (non-Javadoc)
	 * To fetch a list of all the flights from database
	 * @see com.cg.airlinereservation.dao.ICustomerRepository#getAllFlights(com.cg.airlinereservation.entities.FlightInfo)
	 */
	@Override
	public List<FlightInfo> getAllFlights(FlightInfo flight)
			throws ARSException {
		TypedQuery<FlightInfo> query = manager.createQuery("SELECT f FROM flightInfo f where upper(arr_city) = :parrCity AND upper(dep_city) = :pdepCity  AND dep_date = :pdepDate  AND FirstSeats >= :pfirstSeats AND bussSeats >= :pbussSeats", FlightInfo.class);
		query.setParameter("parrCity", flight.getArrCity().toUpperCase());
		query.setParameter("pdepCity", flight.getDepCity().toUpperCase());
		query.setParameter("pdepDate", flight.getDepDate());
		query.setParameter("pfirstSeats", flight.getFirstSeats());
		query.setParameter("pbussSeats", flight.getBussSeats());
		List<FlightInfo> flightList = query.getResultList();
		if(flightList.isEmpty()){
			myLogger.error("No Flights Found");
			throw new ARSException("No Flights Found");
		}
		return flightList;
	}


	/* (non-Javadoc)
	 * To persist/add a new booking to the database
	 * @see com.cg.airlinereservation.dao.ICustomerRepository#addBookingInfo(com.cg.airlinereservation.entities.BookingInfo)
	 */
	@Override
	public void addBookingInfo(BookingInfo Booking_id)throws ARSException {
		manager.persist(Booking_id);

	}

	/* (non-Javadoc)
	 * To delete a booking from the database
	 * @see com.cg.airlinereservation.dao.ICustomerRepository#deleteBooking(com.cg.airlinereservation.entities.BookingInfo)
	 */
	@Override
	public void deleteBooking(BookingInfo bookingInfo) throws ARSException {
		BookingInfo deleteInfo=manager.find(BookingInfo.class, bookingInfo.getBooking_Id());
		myLogger.info(deleteInfo);
		manager.remove(deleteInfo);


	}

	/* (non-Javadoc)
	 * To return an auto-generated bookingId with the use of a sequence
	 * @see com.cg.airlinereservation.dao.ICustomerRepository#bookingId()
	 */
	@Override
	public int bookingId() throws ARSException {
		Query query = manager.createNativeQuery("select booking_id_seq.NEXTVAL from DUAL");
		BigDecimal id = (BigDecimal) query.getSingleResult();
		String str = id+"";
		int bookingId = Integer.parseInt(str);
		myLogger.info(bookingId);
		return bookingId;
	}

	/* (non-Javadoc)
	 * To fetch a particular booking information from its bookingID
	 * @see com.cg.airlinereservation.dao.ICustomerRepository#getBookingInfo(java.lang.String)
	 */
	@Override
	public BookingInfo getBookingInfo(String bookingId) throws ARSException {
		BookingInfo bookingInfo = manager.find(BookingInfo.class, bookingId);
		if(bookingInfo==null)
		{
			throw new ARSException("No Such Booking ID found");
		}
		return bookingInfo;
	}

	/* (non-Javadoc)
	 * To fetch all bookings of a particular using from his uMail
	 * @see com.cg.airlinereservation.dao.ICustomerRepository#getAllBookings(java.lang.String)
	 */
	@Override
	public List<BookingInfo> getAllBookings(String uMail) throws ARSException {

		TypedQuery<BookingInfo> query = manager.createQuery("SELECT b FROM bookingInfo b where uMail = :puMail", BookingInfo.class);
		query.setParameter("puMail", uMail);
		List<BookingInfo> bookingList = query.getResultList();
		if(bookingList.isEmpty())
		{
			throw new ARSException("No Bookings Found for Customer, Sorry!");
		}
		else{
			return bookingList;
		}
	}


	/* (non-Javadoc)
	 * To fetch all the customers of the system
	 * @see com.cg.airlinereservation.dao.ICustomerRepository#getAllCustomers()
	 */
	@Override
	public List<UserARS> getAllCustomers() throws ARSException {
		TypedQuery<UserARS> query = manager.createQuery("SELECT u FROM UserARS u where role = 'CUSTOMER' ", UserARS.class);
		List<UserARS> userList = query.getResultList();
		return userList;
	}

	/* (non-Javadoc)
	 * To get a specific customer details 
	 * @see com.cg.airlinereservation.dao.ICustomerRepository#getCustomerDetails(com.cg.airlinereservation.entities.UserARS)
	 */
	@Override
	public UserARS getCustomerDetails(UserARS customer) throws ARSException {

		TypedQuery<UserARS> query = manager.createQuery("SELECT u FROM UserARS u where userName = :puserName ", UserARS.class);
		query.setParameter("puserName", customer.getUserName());
		return query.getSingleResult();

	}
}
